# EVT2 SPIM3 / SPIM1 silent-failure diagnostic pack

For Ressa @ Nordic — follow-up on the EVT2 SPI3 / flash thread.

## What to read first

**`post/devzone_post_9151_spim3_dead.md`** — the full investigation
write-up. TL;DR + evidence + ruled-out hypotheses + open hypothesis
+ four questions. Read this first; everything else in this pack is
referenced from it.

## Layout

```
post/
  devzone_post_9151_spim3_dead.md     <- start here

test_apps/
  flash_test_evt2/         <- the 9151-side test. The "Test 1..6"
                              evidence in the post comes from this app.
                              Reproduces the SPIM3 + SPIM1 failures.
  flash_test_l15_evt2/     <- L15-side test. Writes PALR + counter to
                              the chip at address 0x000000 (full
                              erase / page-program / persistence cycle).
                              flash_test_evt2's bit-bang section reads
                              back what THIS app wrote.
  flash_test_dk/           <- 9151 DK + external W25Q64 sanity test.
                              Confirmed the test rig + SPI code work on
                              an unmodified DK before we suspected EVT2.

board_files/
  nrf9151_nova_evt2/       <- custom board files for the 9151 side
                              of EVT2. spi3 + i2c2 + uart0 (sw-lpuart)
                              + spi1 (nRF7000) lives here.
  nrf54l15_nova_evt2/      <- L15 side of EVT2. spi00 to the same
                              physical flash chip lives here.
```

## How to reproduce the failure

1. Build & flash `test_apps/flash_test_l15_evt2/` onto the L15 — this
   writes `"PALR" + uint32 counter` to flash address 0x000000.
   ```
   west build -p -b nrf54l15_nova_evt2/nrf54l15/cpuapp/ns \
       -d build -- -DBOARD_ROOT=<path>/palroc_nova
   ```
   Watch RTT for `*** WRITE+READ MATCH ***`. Reset a couple of times,
   confirm the counter persists.

2. Erase the L15:
   ```
   nrfjprog --eraseall -f NRF54L --snr <L15_serial>
   ```

3. Build & flash `test_apps/flash_test_evt2/` onto the 9151:
   ```
   west build -p -b nrf9151_nova_evt2/nrf9151/ns -d build \
       -- -DBOARD_ROOT=<path>/palroc_nova
   ```
   RTT will show:
   - GPIO pin probes (all four pins healthy)
   - Bit-bang JEDEC read returning `EF 40 18` PASS
   - Bit-bang READ DATA returning the PALR marker the L15 wrote
   - Then the Zephyr SPI driver: `iter N: JEDEC 00 00 00`

4. To reproduce the SPIM1 test:
   In `flash_test_evt2/`, the `boards/nrf9151_nova_evt2_nrf9151_ns.overlay`
   already remaps spi1 to the flash pins (with nRF7000 child disabled).
   In `src/main.c`, the device label is `DT_NODELABEL(spi1)`. Build &
   flash as above. Same `00 00 00` result.

5. To reproduce the secure-mode test:
   Build with `nrf9151_nova_evt2/nrf9151` (no `/ns`). Same `00 00 00`.

## Notes

- All RTT output in `flash_test_evt2` uses `printk` because the Zephyr
  log subsystem's deferred queue was eating our diagnostic lines under
  burst load. We've put `k_msleep(50)` between critical prints; even
  so some sections may truncate. The bit-bang results and the iter
  lines are the load-bearing evidence and always make it out cleanly.
- The L15 must be erased (no firmware running) during the 9151 tests
  — otherwise L15 firmware (which might or might not touch SPI3)
  would contend on the shared bus.
- `nRF7000` Wi-Fi works on SPIM1 in our **full bring-up firmware**
  (separate Zephyr app, not in this pack), so SPIM1 silicon is provably
  functional. The fact that SPIM1 fails in `flash_test_evt2` despite
  this is the deepest puzzle.

## Contact

Posted in DevZone thread: <fill-in-thread-URL-when-replying>
By: Oriol @ palroc.com
